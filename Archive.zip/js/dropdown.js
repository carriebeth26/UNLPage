$(document).ready(function() {
    $(function() {
    $('.dropdown-toggle').dropdown()
  });
});

